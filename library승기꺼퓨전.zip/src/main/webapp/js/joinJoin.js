function checkValue() { 
	 	
		var idDuplication = document.getElementById("idDuplication").value;
	
		 if (idDuplication != "idCheck"){
			  alert("아이디 중복체크를 해주세요");
			  return false;
		 }
	}
	

	
	
	
	



				
 function inputIdChk(){     
var idDuplication = document.getElementById("idDuplication").value;
    idDuplication ="idUncheck";     
}
