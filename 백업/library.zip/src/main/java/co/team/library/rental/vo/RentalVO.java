package co.team.library.rental.vo;

import java.sql.Date;

public class RentalVO {
	private String id;
	private String bookCode;
	private Date rentalDate;
	private Date returnDate;
	private int returnBook;
	private int returnComplOrNot;
	
}
